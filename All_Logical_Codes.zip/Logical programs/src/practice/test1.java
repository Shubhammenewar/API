package practice;

import java.util.Map;
import java.util.TreeMap;

public class test1 {
	public static void main(String[] args) {
		String str="My name is Shubham";
		String str1=str.toLowerCase();
		System.out.println(str1);
		char [] str2=str1.replace(" ","").toCharArray();

		System.out.println(str2);

		Map <Object,Integer> map=new TreeMap<>();
		for(int i=0;i<=str2.length-1;i++) {
			int count=0;
			for(int j=0;j<str2.length;j++)
			{
				if(str2[i]==str2[j])
				{
					count++;
				}

			}
			map.put(str2[i], count);
		}
		System.out.println(map);
	}
}
