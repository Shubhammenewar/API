package practice;


import java.util.*;


public class occOfChar {
public static void main(String[] args) {
	String names="Hemant Rajendra Patil";
	String name=names.replace(" ","");
	char [] a=name.toCharArray();
	
	Map<Object,Integer> map=new HashMap<>();
	
	for(int i=0;i<=a.length-1;i++) {
		
		int count = 0;
		for(int j=0;j<a.length;j++) {
			
			if(a[i]==a[j]) {
				
				count++;
			}
		}
		map.put(a[i], count++);	
	}
	System.out.println(map);
}
}
