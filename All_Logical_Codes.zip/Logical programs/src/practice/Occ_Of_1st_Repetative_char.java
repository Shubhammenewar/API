package practice;
import java.util.*;
public class Occ_Of_1st_Repetative_char {
public static void main(String[] args) {
	String name="tomato";
	char [] word=name.toCharArray();
	
	Map<Object,Integer> map=new TreeMap<>(); 
	for(int i=0;i<=word.length;i++) {
		int count=0;
		for(int j=0;j<=word.length;) {
		while(word[i]==word[j]) {
			count++;
		}
		}
		map.put(word[i], count);
	}
	System.out.println(map);
}
}
