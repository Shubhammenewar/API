package practice;

public class method {
	
	    public static void main(char args[]) {
		System.out.println("Orange");
		}

		public static void main(int arg[]) {
		
		System.out.println(10);
		}
		public static void main(String[] args) {
			
			System.out.println("Apple");
			
		
			
		}
	
}
