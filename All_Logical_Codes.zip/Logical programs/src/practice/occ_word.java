package practice;

import java.util.*;

public class occ_word {
public static void main(String[] args) {
	String word="shubham, my name is shubham";
	String wd=word.replace("," ,"");
	System.out.println(wd);
	String[] wdr=wd.split(" ");
	
	Map <Object,Integer> map= new TreeMap<>();
	for(int i=0; i<wdr.length-1;i++) {
		int count=0;
		for(int j=0; j<wdr.length;j++) {
			if(wdr[i].equals(wdr[j])) {
				count++;
			}
		}
		map.put(wdr[i], count);
		
	}
	System.out.println(map);
}
}
