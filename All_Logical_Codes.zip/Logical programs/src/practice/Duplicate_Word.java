package practice;

import java.util.ArrayList;

public class Duplicate_Word {
public static void main(String[] args) {
	String sentence="Hi shubham , I am also shubham shubham";
	
	String[] word=sentence.split(" ");
	//boolean flag=false;
	 String  Duplicate_Word = null;
	
	for(int i=0; i<=word.length-1;i++) {
		for(int j=i+1; j<=word.length-1;j++) {
			if(word[i].equals(word[j])) {
				Duplicate_Word=word[i];
				//flag=true;
			}
			
		}
		
	}
	System.out.println("Duplicate word found>>"+Duplicate_Word);
	/*
	 * if (flag==false) { System.out.println("Duplicate word not found"); }
	 */
	}
}

