package practice;

public class Duplicate {
	public static void main(String[] args) {
        String name="Shubham";
        int Count=0;
        
        for(int i=0;i<name.length();i++){
        	 //int Count=0;
           for(int j=0;j<name.length();j++){
            if(name.charAt(i)==name.charAt(j)) {
            Count++;
            }
        }
           if(Count>1){
               
   			System.out.println("repetative char is>>"+name.charAt(i));
   			
           }
        }
        
        
    }
}
