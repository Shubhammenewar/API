package Star_Pattern;

public class Star3 
{
	//*
	//* *
	//* * *
	//* * * *
	
	public static void main(String[] args) 
	{
		
		
		for(int i=1; i<=4; i++)
		{
			for(int a=1; a<=i; a++)
			{
				System.out.print("*"+" ");
			}
			
			System.out.println();
			
		
		}
		
		
	}

}
