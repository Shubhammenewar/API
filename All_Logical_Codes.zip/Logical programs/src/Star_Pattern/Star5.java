package Star_Pattern;

public class Star5 
{
	//      *
	//    * *
	//  * * *
	//* * * *
	
	
	public static void main(String[] args)
	{
		int Space=3;
		int Star=1;
		
		for(int i=1; i<=4; i++)
		{
			for(int a=1; a<=Space; a++)
			{
				System.out.print(" ");
			}
			
			for(int b=1; b<=Star; b++)
			{
				System.out.print("*");
			}
			
			System.out.println();
			
			Space--;
			Star++;
		}
		
	}
}
