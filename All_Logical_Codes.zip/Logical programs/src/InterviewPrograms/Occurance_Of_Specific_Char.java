package InterviewPrograms;

public class Occurance_Of_Specific_Char {
static	String str="Maharashtra";
static	int occ1=count_occurence(str,'a');
static  int occ2=count_occurence(str,'h');
static	int occ3=count_occurence(str,'r');

public static int count_occurence( String input , char targetChar ) {
	
	int count=0;
	
	for(int c:input.toCharArray()) {
		if(c==targetChar) {
			count++;
		}
	}
	return count;
}
public static void main(String[] args) {
	
	System.out.println("occ of a="+occ1);
	System.out.println("occ of h="+occ2);
	System.out.println("occ of r="+occ3);
	
} 
}
