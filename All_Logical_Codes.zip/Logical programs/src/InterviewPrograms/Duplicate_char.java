package InterviewPrograms;

public class Duplicate_char 
{
	public static void main(String[] args) 
	{
		
		String s="JavaDevellopper";
		
		char[] c=s.toCharArray();
		
		boolean flag=false;
		
		for(int i=0; i<=c.length-1; i++)
		{
			for(int j=i+1; j<=c.length-1; j++)
			{
				if(c[i]==c[j])
				{
					System.out.println("Duplicate Char are =  "+c[i]);
					flag=true;
				}
			}
	
		}
		if(flag==false)
		{
			System.out.println("Duplicate Char not found");
		}
			
		
	}

}
