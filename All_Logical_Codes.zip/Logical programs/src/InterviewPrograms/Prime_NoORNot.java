package InterviewPrograms;

public class Prime_NoORNot 
{

	public static void main(String[] args) 
	{
		int a=13;
		int count=0;
		
		
		for(int i=2; i<a;  i++)
		{
			
			if(a%i==0)
			{
				count++;
				break;
			}
		}
		
		if(count==1)
		{
			System.out.println("The Given No. is not an Prime No.");
		}
		else
		{
			System.out.println("The Given No. is a Prime No.");
		}
	}
}
