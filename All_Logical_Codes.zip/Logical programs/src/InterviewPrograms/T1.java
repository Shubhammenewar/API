package InterviewPrograms;

public class T1 
{
	public static void main(String[] args)
	{
		int Org=153;
		int sum=0;
		
		for(int i=Org;  i>0;  i=i/10)     
		{
			int Rem= i % 10; //3  5 1
			sum= sum*10 + Rem;
		}
		System.out.println(sum);
 
	}

}
