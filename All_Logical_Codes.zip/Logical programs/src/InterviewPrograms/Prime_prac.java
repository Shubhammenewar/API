package InterviewPrograms;



public class Prime_prac 
{

	public static void main(String[] args) 
	{
		int a=17;
		int count=0;
		
		for(int i=2; i<a; i++)
		{
		
			if(a%i==0)
			{
				count++;
				break;
			}
		
		}
		
		if(count==0)
		{
			System.out.println("The given no. is an Prime No.");
		}
		else
		{
			System.out.println("The given no. is not an Prime No.");
		}
	}
}
