package InterviewPrograms;



public class Pallendrome_OR_Not 
{

	public static void main(String[] args) 
	{
		
	  String Org="madam";
	  
	  String Rev="";
	  
	  for(int i=Org.length()-1; i>=0 ; i--)
	  {
		  Rev=Rev + Org.charAt(i);
	  }
	  System.out.println(Rev);
	  
	  if(Org.equals(Rev))
	  {
		  System.out.println("The given string is Pallendrome");
	  }
	  
	  else
	  {
		  System.out.println("The given string is not an Pallendrome");
	  }
	}
}
