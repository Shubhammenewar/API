package InterviewPrograms;

import java.util.HashMap;
import java.util.Set;

public class Occurance_of_Each_char_using_Hashmap 
{
	public static void main(String[] args) 
	{
		String Org="Maharashtra";
		
		HashMap<Character, Integer> mp=new HashMap<Character, Integer> ();
		
		for(int i=0;  i<=Org.length()-1; i++)
		{
			char CharValue=Org.charAt(i);
			
			if(mp.containsKey(CharValue))
			{
				mp.put(CharValue, mp.get(CharValue)+1);
			}
			else
			{
				mp.put(CharValue, 1);
			}
			
		}
		
		Set<Character> keys=mp.keySet();
		
		for(Character key:keys)
		{
			System.out.println(key+":"+mp.get(key));
		}
	}

}
