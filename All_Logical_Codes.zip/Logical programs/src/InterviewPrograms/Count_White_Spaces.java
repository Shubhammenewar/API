package InterviewPrograms;

public class Count_White_Spaces 
{
	public static void main(String[] args)
	{
		String Org="ab a bcd d";
		int Count=0;
		
		for(int i=0; i<=Org.length()-1; i++)
		{
			char CharValue=Org.charAt(i);
			
			if(CharValue==' ')
			{
				Count++;
			}
	
		}
		
		System.out.println(Count);
		
	}

}
