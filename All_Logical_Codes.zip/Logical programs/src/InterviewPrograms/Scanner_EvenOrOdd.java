package InterviewPrograms;

import java.util.Scanner;

public class Scanner_EvenOrOdd 
{

	public static void main(String[] args)
	{
		Scanner Scan=new Scanner(System.in);
		
		System.out.println("Enter Number=");
		int Num=Scan.nextInt();
		
	
		if(Num%2==0)
		{
			System.out.println("The Given No. is Even No.");
		}
		else
		{
			System.out.println("The Given No. is Odd No.");
		}
	}
}
