package InterviewPrograms;

public class String_Compare {
public static void main(String[] args) {
	String str1="Toaday is Thurshday";
	String str2="Thurshday";
	
	//compare tow String
	if (str1.equals(str2)) {
        System.out.println(str2+" is present in str1");
    } else {
        System.out.println("The 1st String Not contain 2nd String");
    }
	
	//Check 2nd String value contain 1st String value or not
	if (str1.contains(str2)) {
        System.out.println("The two strings are equal.");
    } else {
        System.out.println("The two strings are not equal.");
    }
}
}
