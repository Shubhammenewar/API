package InterviewPrograms;

public class Multiply_Without_Multiplication_Op 
{
	
	public static void main(String[] args)
	{
		int num1=5;
		
		int num2=2;
		
		int sum=0;//2, 4, 6, 8, 10
		
		//i=1		1<=5     2
				  //2<=5	 3
				  //3<=5     4
		          //4<=5	 5
				  //5<=5     6
				  //6<=5 False
	
		for(int i=1; i<=num1; i++)
		{
			sum = sum + num2;//2 , 2+2, 4+2, 6+2, 8+2
		}
		
		System.out.println(sum);
	}

}
