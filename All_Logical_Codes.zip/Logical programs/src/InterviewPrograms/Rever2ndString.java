package InterviewPrograms;

public class Rever2ndString {
	public static void main(String[] args)
	{
		String str="Hello Java";
		String[] strArr = str.split(" ");   // spliting the given string By Space
		String rev="";
		String strr = strArr[1];             //index to reverce the string
		
	
		for(int i=strr.length()-1; i>=0;i--)
		{
			rev= rev+strr.charAt(i);
		}
		str = str.replace(strr, rev);
		
		System.out.println(str);
	}
}
