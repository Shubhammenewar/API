package InterviewPrograms;

public class MergeString_char_1By1 {
	public static void main(String[] args) {
        String str1 = "abcd";
        String str2 = "pqrs";

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < Math.max(str1.length(), str2.length()); i++) {
            if (i < str1.length()) {
                result.append(str1.charAt(i));
            }
            if (i < str2.length()) {
                result.append(str2.charAt(i));
            }
        }

        System.out.println(result.toString());
    }
}
