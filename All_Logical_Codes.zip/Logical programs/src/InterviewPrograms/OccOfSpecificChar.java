package InterviewPrograms;

public class OccOfSpecificChar {
	
		public static void main(String[] args) {
	        String str = "Maharashtra";
	        int countA = 0, countR = 0, countH = 0;

	        for (char c : str.toCharArray()) {
	            if (c == 'a' || c == 'A') {
	                countA++;
	            } else if (c == 'r' || c == 'R') {
	                countR++;
	            } else if (c == 'h' || c == 'H') {
	                countH++;
	            }
	        }

	        System.out.println("Occurrences of 'a': " + countA);
	        System.out.println("Occurrences of 'r': " + countR);
	        System.out.println("Occurrences of 'h': " + countH);
	    }
	}

