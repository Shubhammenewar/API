package InterviewPrograms;

public class T2 
{

	public static void main(String[] args)
	{
		String org="maharahstra";
		System.out.println(Recursive(org));
	}

	private static String Recursive(String org)
	{
		if(org==null || org.length()<=1)
		{
			return org;
		}
		
		return Recursive(org.substring(1))+org.charAt(0);
	}
	
}
