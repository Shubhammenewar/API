package InterviewPrograms;


import java.util.Arrays;

public class Array2nd_Smallest {

	public static void  smallest(){
		
		int a[]	={5,8,1,7,3,4};
		//int size=a.length;
		Arrays.sort(a);	
		//System.out.println("Sorted Array :"+Arrays.toString(a));
		//int b= a[1];
		
		System.out.println("2nd smallest no . is "+ a[1]);	
		
		}
	
	 public static void main(String[] args) {
		 smallest();
		}
}
