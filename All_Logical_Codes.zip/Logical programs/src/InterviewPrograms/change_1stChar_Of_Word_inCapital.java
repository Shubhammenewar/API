package InterviewPrograms;

import java.util.Scanner;

public class change_1stChar_Of_Word_inCapital {
public static void main(String[] args) {
	

	
	String str = "hemant patil pune shubham mayur swapnil Surtam";
//	Scanner Scan = new Scanner(System.in)) 
//		System.out.println("Enter Name:");
//		String S=Scan.next();
		
		String s[] =str.split(" ");
		 for(int i=0;i<=s.length-1;i++){
		   //System.out.println(s.length);
			//System.out.println(s[0]); 
			//System.out.println(s[1]); 
		 String result = s[i].substring(0, 1).toUpperCase() + s[i].substring(1)+"  ";
		 System.out.print(result);
		 }
	}

}

