package InterviewPrograms;

public class Reverseint
{
	public static void main(String[] args)
	{
	String a= "7875362538";
	String b="";//8352635787

	for(int i=a.length()-1; i>=0; i--)
	{
		b=b+a.charAt(i); 
		
	}
	System.out.println(b);
	}
	
}
