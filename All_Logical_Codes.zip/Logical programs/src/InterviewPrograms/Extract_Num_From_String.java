package InterviewPrograms;

public class Extract_Num_From_String {
	public static void main(String[] args) {
        String input = "Shubham1254";
        
        // Using regular expression to extract numbers
        String numbers = input.replaceAll("[^0-9]", "");

        System.out.println("Extracted numbers: " + numbers);
    }
}
