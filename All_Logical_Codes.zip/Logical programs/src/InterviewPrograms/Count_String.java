package InterviewPrograms;

public class Count_String {
			
public void Count_string () {
	
	String str ="SHUBHAM";
	System.out.println(str.length());

	
}
	
public  void Count_StringWord () {
	
		
	}
 public static void main(String[] args) {
	 Count_String s=new Count_String();
	 s.Count_string();
	}
 
}

