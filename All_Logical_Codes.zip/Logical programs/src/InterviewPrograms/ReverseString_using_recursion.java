package InterviewPrograms;

public class ReverseString_using_recursion 
{

	public static void main(String[] args) 
	{
		String A="Saurabh";
		System.out.println(recursion(A));
		
	}
	
	private static String recursion(String Name)
	{
		if(Name==null || Name.length()<=1)
		{
			return Name;
		}

		return recursion(Name.substring(1))+Name.charAt(0);
	}
}
