package InterviewPrograms;

public class Reverse_without_using_loops 
{
	public static void main(String[] args) 
	{
		
	String Org="Saurabh Sawale";
	
	StringBuilder Sb=new StringBuilder();
	
	Sb.append(Org);
	Sb=Sb.reverse();

	System.out.println(Sb);
	
	}
	
}
