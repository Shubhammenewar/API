package InterviewPrograms;

public class stringintconcept
{

	public static void main(String[] args)
	{

		System.out.println(45 + 65+ 88 + "Pritam" + 45 +10);
		System.out.println("Pritam" + 20 + 10);

	}
}
