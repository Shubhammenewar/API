package InterviewPrograms;

import java.util.Map;
import java.util.TreeMap;

public class occOfChar {
public static void main(String[] args) {
	String input="Maharashtra";
	
	char [] aa=input.toCharArray();//{M,A,H,A,R,A,S,H,T,R,A}
	//Map<Object,Integer> map=new TreeMap<>();
	
	for(int i=0; i<aa.length-1; i++) {
		//int count=0;
		
		for(int j=0; j<aa.length;j++) {
			
			if(aa[i]==aa[j]) {
			//	count++;
				System.out.println(aa[i]);
			}
		}
		//map.put(aa[i], count);
	}
	
	System.out.println(aa);
	
}
}
