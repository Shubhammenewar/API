package InterviewPrograms;

import java.util.Arrays;

public class Array3rd_largest extends Array2nd_Smallest {

	public static void main(String[] args) {
	int A[]	={5,8,1,7,3,4};
	int size=A.length;
	Arrays.sort(A);	
	System.out.println("Sorted Array :"+Arrays.toString(A));
	int B= A[size-3];
	
	System.out.println("3rd Largest No. is "+B);
    
	//Array2nd_Smallest c =new Array2nd_Smallest();
	smallest();
	
	
	}
	
}
