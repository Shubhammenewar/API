package InterviewPrograms;

import java.util.Arrays;

public class Reverse1 
{

	public static void main(String[] args)
	{
		//Reverse String Programs
		String S1="Saurabh";
		
		String S2="";
		
		for(int i=S1.length()-1; i>=0; i--)
		{
			S2 =S2 + S1.charAt(i);
		}
		
		System.out.println(S2);
		
		//Array Program
		int A1[]= {10,23,54};
		
		
		int A2[]= {10,23,54};
		
		int A3[]= {11,23,12};
		
		
		System.out.println(Arrays.equals(A1, A2));
		
		System.out.println(Arrays.equals(A2, A3));
		
		//Multiplication Without using *
		
		int A=8;
		int B=6;
		int C=0;
		
		for(int i=1; i<=8; i++)
		{
			C=C+B;
		}
		 System.out.println(C);
	}
}
