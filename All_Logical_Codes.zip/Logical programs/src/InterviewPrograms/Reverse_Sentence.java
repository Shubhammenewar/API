package InterviewPrograms;

public class Reverse_Sentence // words placeing reverse
{

	public static void main(String[] args) 
	{
		String org="I am playing"; 
		
		String S1=reversesentence(org);
		
		System.out.println(S1);
		
		
	}
	
	public static String reversesentence(String Sentence) //I    am    playing
	{						  				
											//1       2       3
		String[] Text=Sentence.split(" ");  // I     am      Playing
		
		String rev="";
		
		for(int i=Text.length-1; i>=0;  i--)
		{
			rev = rev + Text[i]+" "; //playing  am I
		}
		
		
		return rev;
		
	}
}
