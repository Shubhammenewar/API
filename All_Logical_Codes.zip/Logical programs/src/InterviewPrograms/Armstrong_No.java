package InterviewPrograms;

public class Armstrong_No 
{
	//Verify given no. is Armstrong number or not
	public static void main(String[] args) 
	{
		int org=153;
		int sum=0;//153
		
		// i=153      153>0      15.3
					//15>0		 1.5
					//1>0		 0.1
					//0>0 False
		
		for(int i=org; i>0; i=i/10)
		{
			int rem=i%10;     //reminder= 3   5   1
			sum=sum +(rem*rem*rem);//27  152   153
			
		}
		
		if(sum==org)
		{
			System.out.println("The given No.is an Armstrong Number");
		}
		else
		{
			System.out.println("The given No.is not an Armstrong Number");
		}
		
		
	}

}
