package InterviewPrograms;

public class Reverse_Without_Changing_Position {
	public static void main(String[] args) {
	       
	       String s="Shubham Madan Menewar";
	       String [] ss=s.split(" ");
	       
	       for(int i=0;i<ss.length;i++){
	           for(int j=ss[i].length()-1;j>=0;j-- )
	           {
	               System.out.print(ss[i].charAt(j));
	           }
	           System.out.print(" ");
	       }
	    }
}
