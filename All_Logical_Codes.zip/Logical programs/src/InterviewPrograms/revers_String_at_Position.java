package InterviewPrograms;

public class revers_String_at_Position {
	public static void main(String[] args) {
		
	
	String names = "My name is Shubham";
	String rev = "";
	 
	String [] arr = names.split(" ");
	
	for(int i=0; i<arr.length; i++)
	{
		String value = arr[i];
		String temp ="";
		for(int j=value.length()-1; j>=0 ;j--)
		{
			temp = temp + value.charAt(j);
		}
		rev = rev + " "+temp;
	}
	
	System.out.print(rev);
}
}
