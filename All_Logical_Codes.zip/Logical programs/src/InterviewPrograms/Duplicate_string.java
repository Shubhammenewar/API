package InterviewPrograms;

public class Duplicate_string 
{
	public static void main(String[] args)
	{
		
		String [] Names= {"Anita", "Shanatnu", "Saurabh", "Pritam", "Snehal", "Pritam"};
		
		boolean flag=false;
		
		for(int i=0; i<=Names.length-1; i++)
		{
			for(int j=i+1; j<=Names.length-1; j++)
			{
				if(Names[i]==Names[j])
				{
					System.out.println("Duplicate Name="+Names[i]);
					flag=true;
				}
			}
		}
		
		if(flag==false)
		{
			System.out.println("Duplicate Names not Found");
		}
	}

}
