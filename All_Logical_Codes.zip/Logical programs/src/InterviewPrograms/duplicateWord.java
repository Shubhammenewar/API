package InterviewPrograms;

import java.util.HashMap;
import java.util.Map;

public class duplicateWord {
public static void main(String[] args) {

	    	String sentence = "home sweet home";
	    	String[] words = sentence.split(" ");

	        // Create a HashMap to store word counts
	        Map<String, Integer> wordCounts = new HashMap<>();

	        // Count occurrences of each word
	        for (String word : words) {
	            // If word is already present, increment its count
	            if (wordCounts.containsKey(word)) {
	                wordCounts.put(word, wordCounts.get(word) + 1);
	            } else {
	                // If word is encountered for the first time, add it to the map with count 1
	                wordCounts.put(word, 1);
	            }
	        }

	        // Print duplicate words
	        System.out.println("Duplicate words in the sentence:");
	        for (Map.Entry<String, Integer> entry : wordCounts.entrySet()) {
	            if (entry.getValue() > 1) {
	                System.out.println(entry.getKey());
	            }
	        }
	    }
	

}

