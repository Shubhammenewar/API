package InterviewPrograms;

import java.util.Scanner;

public class Scanner1 
{
	//Addition of two nos by geetong from users
	
	public static void main(String[] args) 
	{
		Scanner Scan=new Scanner(System.in);
		
		System.out.println("Enter Num1=");
		int Num1=Scan.nextInt();
		
		System.out.println("Enter Num2=");
		int Num2=Scan.nextInt();
		
		System.out.println("Addition of Given Nos="+(Num1+Num2));
		
	}
}
