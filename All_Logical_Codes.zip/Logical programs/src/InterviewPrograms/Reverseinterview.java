package InterviewPrograms;

public class Reverseinterview 
{
	public static void main(String[] args) 
	{
		String org="God is Great";
		String A="";
		String B="";
		String C="";
		
		for(int i=2; i>=0; i--)
		{
			A = A + org.charAt(i);
		}
		
		for(int i=6; i>=3; i--)
		{
			B = B + org.charAt(i);
		}
		
		
		for(int i=11; i>=7; i--)
		{
			C = C + org.charAt(i);
		}
		
		System.out.println(A+B+C);
	}

}
