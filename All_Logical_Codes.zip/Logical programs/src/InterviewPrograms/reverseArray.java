package InterviewPrograms;

public class reverseArray {
	public static void main(String[] args) {
		int [] Array ={7,8,9,3,4,6,11,67,98};
		for(int k=Array.length-1 ; k>=0 ; k--) {
		 System.out.print( Array[k] + " ");
		}
	}
}
