package InterviewPrograms;

import java.util.Scanner;

public class Scanner2 
{

	public static void main(String[] args) 
	{
		Scanner Scan=new Scanner(System.in);
		
		System.out.println("Enter Name of Student:");
		String StudentName=Scan.next();
		
		System.out.println(StudentName);
		
	}
}
