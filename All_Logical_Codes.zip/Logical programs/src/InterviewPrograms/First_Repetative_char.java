package InterviewPrograms;

public class First_Repetative_char {

	public static void main(String[] args) {
		String s="javaDev";
		for(int i=0;i<s.length();i++) {
			int count=0;
			for(int j=1;j<s.length();j++) {
				if(s.charAt(i)==s.charAt(j)) {
					count++;
				}
			}
			if(count>1) {
				System.out.println("first repetative charecter is>>"+s.charAt(i));
				//break;
			}
		}
	}

}
