package InterviewPrograms;

public class Reverse_No
{
	public static void main(String[] args) 
	{
		int Org=121;   //54321
		
		int Rev=0;
		
		//i=12345    12345>0 	1234.5
					//1234>0	123.4
					//123>0		12.3
					//12>0		1.2
					//1>0		0.1
					//0>0 False
		
		for(int i=Org; i>0; i=i/10)
		{
			int rem =  i %10; //5  4 3 2 1 
			Rev= Rev*10+  rem;//54321
		}
		System.out.println(Rev);
	if(Org==Rev) {
		System.out.println("no is pallendrom");
	}
	else {
		System.out.println("no is not pallendro");
	}
	}

}
