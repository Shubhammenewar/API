package InterviewPrograms;

public class Duplicate_nos 
{
	public static void main(String[] args) 
	{
		int a[]= {3,1,4,3,7,5,5,4};
		
		for(int i=0; i<a.length;  i++)
		{
			for(int j=i+1; j<a.length; j++)
			{
				if(a[i]==a[j])
				{
					System.out.println("Dusplicate No.="+a[i]);
				}
				
			}
			
		}
		
	}

}
