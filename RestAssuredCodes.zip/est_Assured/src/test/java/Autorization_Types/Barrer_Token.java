package Autorization_Types;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;


public class Barrer_Token {

	@Test
	public void barrer_token() {
		
		String BarrerToken="Bearer 1029c66935deb431e0fc2805b3259e2b6b259e60ae2f5d84152793ae96e3c8c2";
		RestAssured.baseURI="https://gorest.co.in/public/v2/users";
		
		JSONObject payload=new JSONObject();
		payload.put("name","Shubham");
		payload.put("email", "menewars@gmail.com");
		payload.put("gender", "Male");
		payload.put("Status","Active");
		
		
		Response response=given().contentType(ContentType.JSON).headers("Authorization","BarrerToken").
				log().body().body(payload.toJSONString()).when().post().then().assertThat().
				statusCode(201).extract().response();
		
		System.out.println(response.getStatusCode());
		
		
	}
}
