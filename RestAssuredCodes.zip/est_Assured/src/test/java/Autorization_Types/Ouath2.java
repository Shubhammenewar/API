package Autorization_Types;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
public class Ouath2 {

	String AccessToken="cnbdghchdgcchdbchjb";
	
	@Test
	public void outh2() {
	RestAssured.baseURI="http://www.dummyurl.com";
	
	Response response=given().auth().oauth2(AccessToken).when()
						.get().then().assertThat().statusCode(200).
						extract().response();
		System.out.println(response.getStatusCode());
	}
}
