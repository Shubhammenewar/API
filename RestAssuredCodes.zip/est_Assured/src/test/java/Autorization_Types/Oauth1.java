package Autorization_Types;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class Oauth1 {

	String consumerKey="cbdcwejhbejiugedhfhegh";
	String consumerSecret="sabhscgdhbhjeevfyuffeh";
	String accessToken="nnkvjkhuigeevvjhvjjabscbdjbcddb";
	String tokenSecret="ccndcmbsxnbhsvhjdgkjcbdjkbchc";
			
	@Test
	public void oauth1() {
	RestAssured.baseURI="http://www.dummy.com";
	
	Response response=given().auth().oauth(consumerKey, consumerSecret, accessToken, tokenSecret)
						.when().get()
						.then().assertThat()
						.statusCode(200).extract().response();
		System.out.println(response.getStatusCode());
		System.out.println(response.getStatusLine());
		System.out.println(response.getBody().asString());
	}
}
