package Autorization_Types;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class API_Key {

	@Test
	public void apiKey() {
		RequestSpecification req= RestAssured.given();
		req.baseUri("https://openweathermap.org/");
		req.basePath("/data/2.5/weather");
		req.queryParam("City name","Pune").queryParam("Shubham", "455641e0d1f1ebe5fe7a799f01159061");
		Response res=req.get();
	
	}
}
