package Autorization_Types;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class Diagest {

	@Test
	public void diagest() {
		RestAssured.baseURI="http://httpbin.org/digest-auth/undefined/Shubham/ShubhamM";
		Response response=given().auth().digest("Shubham","ShubhamM").when().get()
				.then().assertThat().statusCode(200).extract().response();
		System.out.println(response.getStatusCode());
		System.out.println(response.getStatusLine());
	}
}
