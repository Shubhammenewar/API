package POJO;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;
import io.restassured.response.Response;

public class Serialization_and_Deserialization {
@Test
public void Serialization() throws JsonProcessingException {
	Employee_Data_Member Dm= new Employee_Data_Member();
	Dm.setFirstname("Shubham");
	Dm.setLastname("Menewar");
	Dm.setGender("Male");
	Dm.setAge(28);
	Dm.setSalary(200000.00);

//>>>>>>>>>>convert DataMember class object to Json payload as String
	
ObjectMapper Obj=new ObjectMapper();

String StringToJson= Obj.writerWithDefaultPrettyPrinter()
.writeValueAsString(Dm);

System.out.println(StringToJson);

RestAssured.baseURI="http://httpbin.org/post";
Response res=given().contentType(ContentType.JSON).body(StringToJson)
			.when().post().then().assertThat().log()
			.all().extract().response();

res.prettyPrint();//to print

//convert JSON to Java Object

}
}
