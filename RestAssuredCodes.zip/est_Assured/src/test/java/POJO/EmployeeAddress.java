package POJO;

public class EmployeeAddress {
private 

}
