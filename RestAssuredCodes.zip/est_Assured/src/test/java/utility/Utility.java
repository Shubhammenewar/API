package utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Utility {

public static String properties(String Url) throws IOException {
	
	Properties prop=new Properties();
	FileInputStream fis= new FileInputStream("D:\\Software Testing Class\\Pakages\\est_Assured\\Data.properties");
	prop.load(fis);
	return prop.getProperty("BaseURL");
	
	
}
}
