package validation;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import junit.framework.Assert;

import static io.restassured.RestAssured.*;

public class Json_Validation {

	@Test
	public void json_validation() {
	
		RestAssured.baseURI="https://reqres.in/api/users/2";
		Response response=given().header("contentType","application/json")
							.body("{\r\n"
									+ "    \"name\": \"Shubham\",\r\n"
									+ "    \"job\": \"zion resident\"\r\n"
									+ "}")
							.when().put().then().assertThat().statusCode(200)
							.log().all().extract().response();
		
							JsonPath js= response.jsonPath();
							
							String Name=js.get("data.name");
							System.out.println("My Updated Name is:"+Name);
							Assert.assertEquals(Name,"Shubham");
							System.out.println("Status Code is>>"+response.getStatusCode());
							
	}
}
