package validation;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import junit.framework.Assert;

import static io.restassured.RestAssured.*;
public class XML_Data_Validation {

	@Test
	public void xmlValidation() {
	 RestAssured.baseURI="https://www.w3schools.com";
	 
	 Response res=given().when().get("/xml/simple.xml").then().log()
			 			.all().statusCode(200).
			 			contentType("text/xml").extract().response();
	
	
	
	 	XmlPath xml= new XmlPath(res.asString());
	 	
	 	
	 	String name=xml.getString("breakfast_menu.food[1].name");
	 	System.out.println("name is>>"+name);
	 	Assert.assertEquals(name,"Strawberry Belgian Waffles");

	 	String price=xml.getString("breakfast_menu.food[1].price");
	 	System.out.println("Price is>>"+price);
	 	Assert.assertEquals(price,"$7.95");
	 	
	 	String description=xml.getString("\"breakfast_menu.food[1].description");
	 	System.out.println("description is>>"+description);
	 	Assert.assertEquals(description, "Light Belgian waffles covered with strawberries and whipped cream");
	 		 	
	 	
	}
}
