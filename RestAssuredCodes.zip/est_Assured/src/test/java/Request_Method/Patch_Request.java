package Request_Method;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Patch_Request {

	@Test
	public void patch() {
		
			
		RestAssured.baseURI="https://reqres.in/api/users/2";
		Response response=given().contentType("application/json")
				.body("{\r\n"
						+ "    \"name\": \"Shalin\",\r\n"
						+ "    \"job\": \"Devil\"\r\n"
						+ "}").when().patch().then().assertThat()
				.statusCode(200).log().all().extract().response();
		
		JsonPath js=response.jsonPath();
		String Name=js.getString("name");
		
		
		System.out.println("Status Code Patch Request>>"+response.getStatusCode());
		System.out.println("Status Line Patch Request>>"+response.getStatusLine());
	}
}
