package Request_Method;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class Put_Request {

	@Test
	public void Put() {
		
	RestAssured.baseURI="https://reqres.in/api/users/2";
	Response response=given().contentType("application/json")
			.body("{\r\n"
					+ "    \"name\": \"Shubham\",\r\n"
					+ "    \"job\": \"Automation Test Analyst\"\r\n"
					+ "}").when().put().then().assertThat()
			.statusCode(200).log().all().extract().response();
	
	JsonPath js=response.jsonPath();
	String Name=js.getString("name");
	
	
	System.out.println("Status Code Put Request>>"+response.getStatusCode());
	System.out.println("Status Line Put Request>>"+response.getStatusLine());
	
	}
}
