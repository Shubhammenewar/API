package Request_Method;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class Get_Headers {

	@Test
	public void H_get_Headers(){
		RestAssured.baseURI="https://fakerestapi.azurewebsites.net/";
		Response response=given().when().get("api/v1/Activities").then().assertThat().
		statusCode(200).extract().response();
		System.out.println(response);
		
		Headers HeaderList=response.getHeaders();
		
		for(Header header:HeaderList) {
			System.out.println("Headers>>"+header.getName()+" "+header.getValue());
		}
	}
}
