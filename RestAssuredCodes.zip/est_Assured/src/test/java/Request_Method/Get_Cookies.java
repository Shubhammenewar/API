package Request_Method;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import java.util.Map;

import org.testng.annotations.Test;
public class Get_Cookies {

	@Test
	public void get_cookies() {
		
		RestAssured.baseURI="https://www.facebook.com/";
		Response response=given().when().get().then().assertThat().statusCode(200).extract().response();
		
		Map<String,String> cookies= response.getCookies();
		
		for(Map.Entry<String, String> cookie:cookies.entrySet()) {
			System.out.println("Cookies>>"+cookie.getKey()+"="+cookie.getValue());
		}
		
	}
}
