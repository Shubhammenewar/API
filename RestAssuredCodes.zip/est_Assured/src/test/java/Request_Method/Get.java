package Request_Method;

import io.restassured.RestAssured;
import io.restassured.response.Response;


import static io.restassured.RestAssured.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;
public class Get {

	@Test
	public void GetRequest() throws IOException  {
		/*
		 * Properties prop=new Properties(); FileInputStream fis= new
		 * FileInputStream("D:\\Software Testing Class\\Pakages\\est_Assured\\Data.properties"
		 * ); prop.load(fis);
		 * 
		 * RestAssured.baseURI=prop.getProperty(prop.getProperty("BaseURL"));
		 */
		 
		RestAssured.baseURI="https://reqres.in";
		Response response=given().when().get("/api/users").
				then().assertThat().statusCode(200).
				extract().
				response();
		
		
		System.out.println("Status Code Get Req>>"+response.getStatusCode());
		System.out.println("Status Line Get Req>>"+response.getStatusLine());
	}
}
