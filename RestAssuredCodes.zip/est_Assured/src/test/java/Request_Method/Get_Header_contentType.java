package Request_Method;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
public class Get_Header_contentType {

	@Test
	public void get_header_ContentType() {
	
		RestAssured.baseURI="https://fakerestapi.azurewebsites.net/";
				
		
		Response response=given().when().get("api/v1/Activities").then().assertThat()
		.statusCode(200).extract().response();
		String contentType=response.getHeader("Content-Type");
		System.out.println("Content-Type>>"+contentType);
		Assert.assertEquals(contentType, "application/json; charset=utf-8; v=1.0");
	
		//Assert.assertEquals(contentType, "application/json; charset=utf-8; v=1.0");
		
	}
}
