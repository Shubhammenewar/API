package Request_Method;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class Post_Request {

	@Test
	public void post() {
		RestAssured.baseURI="https://reqres.in";
		Response response=given().body("{\r\n"
				+ "    \"name\": \"morpheus\",\r\n"
				+ "    \"job\": \"leader\"\r\n"
				+ "}").when().post("api/users").then().
				assertThat().statusCode(201).log().all().extract()
				.response();
		
		System.out.println("Status Code Post Req>>"+response.getStatusCode());
		System.out.println("Status Line Post Req>>"+response.getStatusLine());
	}
}
