package RestAssured_Borle;
import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class Rest_Assured_Demo {
public static void main(String[] args) {
	RestAssured.baseURI="https://reqres.in/";
	//GET Request
//	String response=given().queryParam("page",2).when().get("api/users").
//	then().log().all().extract().response().asString();                       
	
	//System.out.println(response);
	
	//POST Request
	String response=given().body("{\r\n"
			+ "    \"name\": \"morpheus\",\r\n"
			+ "    \"job\": \"leader\"\r\n"
			+ "}")
			
			.when().post("/api/users").then().log().all().extract().response().asString(); 
	
	//System.out.println(response);
	
	//GETID
	        JsonPath js= new JsonPath(response);
	        
	       String ID= js.get("Id");
	        
			System.out.println(ID);
			
	
}

}
