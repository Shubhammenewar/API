package Method_Chaining;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;


public class Put_Method {

	public static int userId;
	@Test
	public void method() {
		
		RestAssured.baseURI="https://reqres.in";
		Response resp=given().queryParam("page",1)
				.when().get("/api/users").then()
				.log().all().statusCode(200).extract()
				.response();
		
		JsonPath js= new JsonPath(resp.asString());
		
		//Extract Id from By Get()
		
		userId=js.getInt("data[0].id");
		System.out.println("User Id of First User:"+ userId);
		
		//Update user details
		
		String updateUserReq="{\n" + 
				"\"name\": \"updatedname\",\n" +
				"\"job\":\"updatedJob\"\n" +
				"}";
		
		//Perform PUT() using Retrieved ID
		
		String putResponse=given().body(updateUserReq)
							.when().put("https:reqres.in/api/users/"+userId)
							.then().log().all().statusCode(200).extract().asString();
		
		
		//Print the Rresponse of the Put()

		System.out.println("Updated details for User with ID"+ userId);
		System.out.println(putResponse);
	}
}
