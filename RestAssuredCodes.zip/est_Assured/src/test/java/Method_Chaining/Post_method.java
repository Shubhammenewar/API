package Method_Chaining;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;
public class Post_method {

	public static String firstName;
	public static String lastName;

	@Test
	public void method1() {
		RestAssured.baseURI="https://reqres.in";
		
		Response response=given().queryParam("?page=2").when().
				get("/api/users").then().assertThat().statusCode(200).
				extract().response();
		
		// Extract Data by get();
		
		JsonPath js=new JsonPath(response.asString());
				
		firstName=js.get("data[0].first_name");
		lastName=js.getString("data[0].last_name");
		
		System.out.println("First Name  of First User Id:"+ firstName);
		System.out.println("Last Name of First User Id"+ lastName);
		
		System.out.println("Status code:200");
		
		//Perform POST Req using data from GET
		
		String reqBody="{\n"+"\"name\":\""+firstName+ ""+lastName+"\",\n"+
		
				"\"job\":\"leader\"\n"+
				"}";
		
		String postResponse= given().body(reqBody).when().
								post("https://reqres.in/api/users").
								then().log().all().statusCode(201).
								extract().asString();
		
		
		System.out.println("Post request successful Response:"+postResponse);
	}
}
